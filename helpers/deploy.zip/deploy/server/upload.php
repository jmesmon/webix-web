<?php
ini_set('max_execution_time', 120);

if (isset($_FILES['upload'])){
     echo "{ status:'error' }";
}
?>