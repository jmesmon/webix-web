//[Skin Customization]
webix.skin.web.barHeight=28;webix.skin.web.tabbarHeight=30;webix.skin.web.rowHeight=30;webix.skin.web.listItemHeight=28;webix.skin.web.inputHeight=28;webix.skin.web.layoutMargin.wide=20;webix.skin.web.layoutMargin.space=20;webix.skin.web.layoutPadding.space=20;
 webix.skin.set('web')